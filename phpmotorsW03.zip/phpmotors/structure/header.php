<header>
	<img src="images/site/logo.png" alt="PHP Motors Logo">
	<p><a id="login-link" href="">My Account</a></p>
</header>