<header>
	<img src="images/site/logo.png" alt="PHP Motors Logo">
	<p><a id="login-link" href="../phpmotors/accounts/?action=account">My Account</a></p>
</header>