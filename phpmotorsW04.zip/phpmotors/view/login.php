<fieldset>
<h2>Sign in</h2>
<fieldset>
<form action='' method='post'>
<label>
	Email Address
	<input type='text' name='log_email' value=''>
</label>
<label>
	Password
	<input type='text' name='log_pass' value=''>
</label>
<input type='submit' value='Login'>
</form>
</fieldset>
No account? <a href='?action=register'>Register one today!</a>
</fieldset>