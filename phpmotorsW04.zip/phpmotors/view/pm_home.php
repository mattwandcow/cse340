<p>Welcome to PHP Motors!</p>
<ul>
<li>
	<a href='./accounts'>Accounts page</a>
</li>
<li>
	<a href='./accounts/?action=login'>Login page</a>
</li>
<li>
	<a href='./accounts/?action=register'>Register page</a>
</li>
</ul>