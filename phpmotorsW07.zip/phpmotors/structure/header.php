<header>
	<img src="<?php echo $depth_str;?>images/site/logo.png" alt="PHP Motors Logo">
	<p><a id="login-link" href="<?php echo $depth_str;?>accounts/?action=account">My Account</a></p>
</header>