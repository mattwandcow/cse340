<footer>
    <p>PHP Motors, All rights reserved</p>
    <p>All images used are belevied to be in "Fair Use" . Please notify the author if any are not and they will be removed.</p>
    <p>Last Updated: 30 March, 2018</p>
</footer>